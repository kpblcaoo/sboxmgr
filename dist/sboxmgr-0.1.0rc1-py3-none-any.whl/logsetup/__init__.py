"""Logging setup package for SBoxMgr."""
