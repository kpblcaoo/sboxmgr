"""IPC (Inter-Process Communication) module for agent."""

from .socket_client import SocketClient

__all__ = ["SocketClient"]
