"""SBoxMgr - Subscription Box Manager.

A comprehensive tool for managing and exporting proxy configurations.
"""

__version__ = "0.52.0"
__author__ = "SBoxMgr Team"
__email__ = "support@sboxmgr.org"

# This file indicates that the package supports type checking
# See PEP 561 for more details
