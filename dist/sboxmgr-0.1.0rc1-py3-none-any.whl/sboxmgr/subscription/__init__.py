"""Subscription management package for SBoxMgr.

This package handles subscription fetching, parsing, and processing.
"""

# This file indicates that the package supports type checking
# See PEP 561 for more details
